===========================================================================================
SIOMICS 3.0 

Author: Jun Ding
Date: Nov. 8,2015
===========================================================================================
SIOMICS 3.0 is a software used to de novo identify monad/dyad motifs from TF-based ChIP-seq datasets 
along with the discovery of motif combinations. It is developed by the computational System biology 
Group at UCF.


* INSTALLATION
--------------------------------------------------------------------------------------------
A. For Linux user 
(1) First, you need to install python 2.7, which is already installed by default for most of 
current Linux systems. If there is no python installed (or your python version is not 2.7), you can download and install 
python from (http://www.python.org/download/). You can use "python -V" command to check whether
python is installed and the version of Python.

(2)You also need Tkinter(Python 2) or tkinter(Python 3) module for Python to enable the GUI.
You can check (http://tkinter.unpythonic.net/wiki/How_to_install_Tkinter) for installation instructions on linux. 


After you have installed the above softwares, you are done.

B.For Windows user
(1) First, you need to install python, which can be obtained from (http://www.python.org/download/).
Please use the python windows installer from the above download package. After finishing downloading,
just double click the installer to get python installed. The python Windows installer already 
included the Tkinter module by default and therefore you do not need to do it manually. 


*Execution 
--------------------------------------------------------------------------------------------------------------------------------------

A. For Linux user
(1) Command Line User
   a. cd to the directory of the software
      For example, if you put XXXX under your home directory  ( "cd /home/YOURNAME/XXXX")
      YOURNAME is the your home directory name. 
   b. You can run the software by running the script "SIOMICS3.py" with the following command:
   
   ----------------------------------------------------------------------------------------
   
   python SIOMICS3.py 
	-i <input_peak_sequences>  Input peak sequences should be in FASTA Format 
	-o <ouput directory>   This parameter used to specify the directory for output results. 
	-m <mode> 0: monad only, 1: dyad only, 2: monad+dyad 
	-n <maximal_number_of_output_motifs> The maximal number of output motifs 
	-s <support_value_of_motif_combination> The minimal number of sequences a motif module need to occur in order to be considered as significant or frequent.
	-c < corrected_pvalue cutoff> The p-value cutoff after multiple comparison correction for motif module.
    -t <1/0> 1: compare predicted motifs with known databases using STAMP, 0:  no comparing 
		if t=1, you need to specify the STAMP comparison parameter -d and -e.
		if t=0, you can just put -d 0 -e 0 
    -d <known TF motif database for STAMP comparison>.  'default' : default database provided by SIOMICS3, or you can specificy your own database. 
       Note: your database must be prepared in TRANSFAC format. We provided a python script formatMat.py in the tools directory 
       You can convert PWM to TRANSFAC motif format with the provided script. 
    -e <E-value cutoff for STAMP comparison> 
   -----------------------------------------------------------------------------------------
   
   For example, if we want to identify motifs from the provided example_seq TF peak dataset located under the directory "example" by using monad+dyad mode
   We can use the following command: 
   ----------------------------------------------------------------------------------------
	A. No motif comparison 
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 0 -d 0 -e 0
	
	B. STAMP with default database
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 1 -d default -e 1e-5
	
	C. STAMP with User defined database
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 1 -d <Path_to_your_database> -e 1e-5
	--------------------------------------------------------------------------------------------
	
(2) GUI user
	Just double click the XXXX_GUI.py and choose "Run in Terminal", you might need to change the permision of X.py by using the following command:
	---------------------------------------------------
        chmod +x X.py 
        ---------------------------------------------------
	
B. For Windows user
(1) Command Line User
   a.open prompt window.
     Open the Command Prompt window by clicking the Start button , clicking All Programs, clicking Accessories, and then clicking Command Prompt.
   b.cd to the directory of software
  
   c.You can run the software by running the script "SIOMICS3.py" with the following command:
   
   ----------------------------------------------------------------------------------------
   
   python SIOMICS3.py 
	-i <input_peak_sequences>  Input peak sequences should be in FASTA Format 
	-o <ouput directory>   This parameter used to specify the directory for output results. 
	-m <mode> 0: monad only, 1: dyad only, 2: monad+dyad 
	-n <maximal_number_of_output_motifs> The maximal number of output motifs 
	-s <support_value_of_motif_combination> The minimal number of sequences a motif module need to occur in order to be considered as significant or frequent.
	-c < corrected_pvalue cutoff> The p-value cutoff after multiple comparison correction for motif module.
    -t <1/0> 1: compare predicted motifs with known databases using STAMP, 0:  no comparing 
		if t=1, you need to specify the STAMP comparison parameter -d and -e.
		if t=0, you can just put -d 0 -e 0 
    -d <known TF motif database for STAMP comparison>.  'default' : default database provided by SIOMICS3, or you can specificy your own database. 
       Note: your database must be prepared in TRANSFAC format. We provided a python script formatMat.py in the tools directory 
       You can convert PWM to TRANSFAC motif format with the provided script. 
    -e <E-value cutoff for STAMP comparison> 
   -----------------------------------------------------------------------------------------
   
   For example, if we want to identify motifs from the provided example_seq TF peak dataset located under the directory "example" by using monad+dyad mode
   We can use the following command: 
   ----------------------------------------------------------------------------------------
	A. No motif comparison 
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 0 -d 0 -e 0
	
	B. STAMP with default database
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 1 -d default -e 1e-5
	
	C. STAMP with User defined database
	python SIOMICS3.py -i example/example_seq -o example_output -m 2 -n 100 -s 20 -c 0.01 -t 1 -d <Path_to_your_database> -e 1e-5
	--------------------------------------------------------------------------------------------
	
	
(2) GUI user
   Just double Click the XXX_GUI.py
	


*Result
----------------------------------------------------------------------------------------------------------------------------------
Result files:
--------------------------
1.   X.PWM  (predicted motifs in PWM format)
2.   X.PWM.TFs (Corresponding TFs for predicted motifs under given E-value cutoff)--
This result is only available under Linux since it is based on STAMP and STAMP is not available under Windows
Although we cant' use STAMP standlone tool under Linux, we can use STAMP on-line server to compare the predicted motifs and known motifs in provided database. 
The on-line comparison results were provided by X.STAMP.pdf, which is downloaded from STAMP server. 
3.   X.STAMP.pdf (STAMP comparison details in PDF for predicted motifs)
4.   X.mc  (Predicted motif combinations)
5.   X.tfbs (The TFBSs for predicted motifs)
6.   X.trans (The transaction file generated for pattern mining)
8.   X.sif (simple interaction file generated for cytoscape visualization)
7.   Running.log

--------------------------

When the software is running, you will see "Running..." on the bottom of the GUI, the GUI probably will show "Not Responding", but it's OK.
You will see "Done" on the bottom of GUI when results were obtained. 



	
* License & Credits
-------------------------------------------------------------------------------------------------
The software is a freely available for academic use. 
The software makes muscle (http://www.ebi.ac.uk/Tools/msa/muscle/) to do the multiple alignment.
The software utilized STAMP server by Shaun Mahony (http://www.benoslab.pitt.edu/stamp/) to do the motif comparison
It is also available for non-academic use under appropriate licensing.
plase contact xiaoman shawn li (xiaoman@mail.ucf.edu) for further information. 





*Contact info
If you are encountering any problem regarding to SIOMICS, please refer the manual first.
If problem still can not be solved, please feel free to contact us:
Jun Ding (jding@cs.ucf.edu)
Nancy Haiyan Hu (haihu@cs.ucf.edu)
Xiaoman Shawn Li (xiaoman@mail.ucf.edu)



