#!/usr/bin/env python
import pdb,sys,os,math,getopt,datetime
from Clique_Dyad import *

#=======================================================================
#
try:
	opts,args=getopt.getopt(sys.argv[1:],'i:m:n:s:c:o:t:r:d:e:')	
	for i in opts:
		if i[0]=='-i':
			inputseq=i[1]
		if i[0]=='-n':
		# n
			nmotifs=int(i[1])
		if i[0]=='-m':
		# mode
			mode=int(i[1])
		if i[0]=='-s':
		# support value
			S=int(i[1])
		if i[0]=='-c':
		# cutoff
			C=float(i[1])
		if i[0]=='-o':
		# output
			outputdir=i[1]
		if i[0]=='-t':
			stamp_comp=int(i[1])
		# stamp
		if i[0]=='-r':
		# iterative
			r=int(i[1])
		if i[0]=='-d':
			db=i[1]
			PP=os.path.dirname(os.path.abspath(__file__))
			#pdb.set_trace()
			if db=='default':
				db=PP+'/Clique_Dyad/STAMP/jaspar2010.motifs'
		if i[0]=='-e':
			ec=float(i[1])
except:
		print ('Please check your input parameters')
		print ("python SIOMICS3.py -i <inputseq> -m <mode:0,1,2> -n <# of motifs> -s <supports> -c <p-value cut> -o <output directory> -t <1/0> Known motif Comparison? -r <1/0> iterative mode? -d <known motif database> -e <STAMP e-value cutoff>")
		sys.exit(0)

if len(opts)!=10:
		print ('Please check your input parameters')
		print ("python SIOMICS3.py -i <inputseq> -m <mode:0,1,2> -n <# of motifs> -s <supports> -c <p-value cut> -o <output directory> -t <1/0> Known motif Comparison? -r <1/0> iterative mode? -d <known motif database> -e <STAMP e-value cutoff>")
		sys.exit(0)


print("start predicting...")
Path2Current=os.path.dirname(os.path.abspath(__file__))
sys.path.append(Path2Current)
Path2Code='%s/Clique_Dyad'%(Path2Current)
sys.path.append(Path2Code)
ctrlseq='%s/CTRL'%(Path2Code)
dmotifs=10
# main function:


########################################################################

log_content="Program starts:\r\n"+str(datetime.datetime.now())+'\r\n'
log_content+="Running command:\r\npython SIOMICS3.py -i %s -m %s -n %s -s %s -c %s -o %s -t %s -d %s -e %s" %(inputseq,mode,nmotifs,S,C,outputdir,stamp_comp,db,ec)+'\r\n'

if mode==0:
	# clique-monad mode
	A=Clique.Clique(inputseq,ctrlseq,nmotifs)
if mode==1:
	# dyad mode
	A=dyad.dyad(inputseq,ctrlseq,dmotifs)
if mode==2:
	A=Clique.Clique(inputseq,ctrlseq,nmotifs)
	B=dyad.dyad(inputseq,ctrlseq,dmotifs)
	A=A+B
	
log_content+="Motif prediction Success!\r\n"
if len(A)==0:
	print ('No motifs were identified! Please check your inputs or parameters!')
	sys.exit(0)
	

A.sort(key=lambda x:(x[0],len(x[1])))
# removing redundant between dyad and monad
#A=A[:nmotifs]

if r==1:
	A=IterativeFind.IterativeFind(A,outputdir,inputseq,ctrlseq,S,C,nmotifs)
else:
	pcut=(1e-10)/(4**8)
	A=[item for item in A if item[0]<pcut]
	A=A[:nmotifs]
# TFBS
TFBSModule.TFBSModule(A,inputseq,outputdir,stamp_comp,db,ec)

# module
FN=inputseq.split(os.sep)[-1]
sigMod=AnalyzeModule.AnalyzeModule(A,outputdir,inputseq,ctrlseq,S,C)
writeMod.writeMod(A,sigMod,outputdir,FN)

#sif->cytoscape
cytoscape.cytoscape(sigMod,outputdir,FN)


#=======================================================================
log_content+="Motif module prediction Success!\r\n"
log_content+='Program ends:\r\n'
log_content+=str(datetime.datetime.now())+'\r\n'
f=open('%s/running.log'%(outputdir),'w')
f.write(log_content)
f.close()

print ('done!')




