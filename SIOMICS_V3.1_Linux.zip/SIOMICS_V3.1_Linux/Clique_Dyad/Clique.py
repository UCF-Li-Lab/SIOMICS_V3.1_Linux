"""
author: jun ding
date: 2015/01/09
function: this code is used to enable gapped motif for SIOMICS
"""
import pdb,sys,os,math,shutil
import networkx as nx
from StatTest import *


#======================================================================================================



# subroutines
# progressbar
def progressbar(count, total, suffix=""):
    bar_len = 60
    filled_len = int(round(bar_len * count / float(total)))

    percents = round(100.0 * count / float(total), 1)
    bar = '=' * filled_len + '-' * (bar_len - filled_len)

    sys.stdout.write('[%s] %s%s ...%s\r' % (bar, percents, '%', suffix))
    sys.stdout.flush()

# read in Sequences
def readSeq(fname):
	f=open(fname,'r')
	lf=f.readlines()
	f.close()
	lf="".join(lf)
	lf=lf.split(">")
	lf=lf[1:]
	for i in range(len(lf)):
		lf[i]=lf[i].split("\n")
		lf[i]=[lf[i][0],''.join(lf[i][1:])]
	return lf
	
# extrac the peak region (200bps around the peak center)

def extracPeak(A,w):
	e=w/2
	B=[]
	for i in A:
		n=len(i[1])
		if n<w:
			B.append(i)
		else:
			B.append([i[0],i[1][n/2-e:n/2+e]])
	return B
		
			
	
# reverse complement
def revcom(A):
	dN={'A':'T','C':'G','G':'C','T':'A','N':'N','R':'Y','Y':'R','M':'K','K':'M','W':'W','S':'S'}
	A=A.upper()
	A=[dN[item] for item in A]
	A=A[::-1]
	A=''.join(A)
	return A
	
# frequency
def freqX(S,x):
	print('\nx-mer counting...')
	dx={}
	bg=[0,0,0,0]
	dN={"A":0,"C":1,"G":2,"T":3}
	ct=0
	for i in S:
		seqi=i[1]
		bg[0]+=seqi.count('A')
		bg[1]+=seqi.count('C')
		bg[2]+=seqi.count('G')
		bg[3]+=seqi.count('T')
		
		for j in range(len(seqi)-x+1):
			mer=seqi[j:j+x]
			if 'N' not in mer:
				if mer not in dx:
					dx[mer]=1
				else:
					dx[mer]+=1
		progressbar(ct,len(S)-1,'')
		ct+=1
	return [dx,bg]


def positionX(S,segs):
	# segs is a list of X-mer list
	if len(segs)==0:
		return []
	AllSeg=reduce(lambda x,y:x+y, segs)
	dxx={i:''.join([item for item in i if item!='-']) for i in AllSeg} # for aligned x-mer, may be longer than x if there's insertion
	x=len(dxx.values()[0])
	dpx={i:[] for i in dxx.values()} # for x-mers
	for i in xrange(len(S)):
		seqi=S[i][1]
		for j in range(len(seqi)-x+1):
			mer=seqi[j:j+x]
			if mer in dxx.values():
				dpx[mer].append((i,j))
	#===
	dsx={}
	for i in dxx:
		A=dxx[i]
		indA=min([j for j in range(len(i)) if i[j]!='-'])
		B=[]
		for j in dpx[A]:
			B.append((j[0],j[1]-indA,j[1]-indA+len(i)))

		dsx[i]=B
	
	MP=[]
	for i in range(len(segs)):
		T=reduce(lambda x,y:x+y, [dsx[item] for item in segs[i]])
		T=list(set(T))
		MP.append(T)
	return MP
			
# 
def bG(S):
	bg=[0,0,0,0]
	for i in S:
		seqi=i[1]
		bg[0]+=seqi.count('A')
		bg[1]+=seqi.count('C')
		bg[2]+=seqi.count('G')
		bg[3]+=seqi.count('T')
	return bg
			
# get signiciant x-mers
def sigX(fx,fc,bg):
	cut=1e-10
	#cut=(1e-2)/(4**8)
	#cut=(1e-2)/len(fx)
	sig_fx=[]
	N=sum(fx.values())
	Nc=sum(fc.values())
	print('\ncalculating significance...')
	ct=0
	n=len(fx)
	for i in fx:
		#==============================================================
		a=fx[i]
		b=fc[i]
		c=N-a
		d=Nc-b
		pv=fisherTest(a,b,c,d)
		if pv<cut:
			sig_fx.append([pv,i,fx[i]])	
		progressbar(ct,n-1)
		ct+=1
	sig_fx.sort()
	for i in range(len(sig_fx)):
		sig_fx[i]=[i,sig_fx[i][1],sig_fx[i][0],sig_fx[i][2]]
	return sig_fx
			
			
# compare 2-xmers
def compare2Xmer(*args):
	if len(args)==3:
		a=args[0]
		b=args[1]
		cut=float(args[2])
	if len(args)==2:
		a=args[0]
		b=args[1]
		cut=1
	if len(a)<len(b):
		tmp=a
		a=b
		b=tmp
	offset=2
	a1='-'*offset+a+'-'*offset
	m=[]
	for i in range(len(a1)-len(b)+1):
		mi=0
		for j in range(len(b)):
			if (a1[i+j]!=b[j]):
				if a1[i+j]!='-':
					mi+=1
				else:
					mi+=0.5
		m.append(mi)
	#if float(min(m))/len(b)<=cut:
	if min(m)<=cut:
		return 1
	else:
		return 0
		
def similarX(freqX):
	print('\nbuilding graph...')
	P=[]
	for i in range(len(freqX)-1):
		for j in range(i+1,len(freqX)):
			xi=freqX[i][1]
			xj=freqX[j][1]
			xj_rc=revcom(xj)
			flag=compare2Xmer(xi,xj)
			flag_rc=compare2Xmer(xi,xj_rc)
			if flag:
				p=(freqX[i][0],freqX[j][0])
				P.append(p)
			elif flag_rc:
				p=(freqX[i][0],freqX[j][0])
		progressbar(i,len(freqX)-1-1, '')
	return P
	
#=======================================================================			
def parseMuscleOut(Fmo):
	f=open(Fmo,'r')
	lf=f.readlines()
	lf="".join(lf)
	lf=lf.split(">")[1:]
	T=[]
	for i in range(len(lf)):
		lf[i]=lf[i].split('\n')
		T+=int(lf[i][0])*[lf[i][1]]
	return T
	
def muscleAlign(A):
	A=[">"+str(item[-1])+'\n'+item[0] for item in A]
	A='\n'.join(A)
	f=open('.%s.tmp'%(FN),'w')
	f.write(A)
	f.close()
	PP=os.path.dirname(os.path.abspath(__file__))
	os.system('%s/muscle -in .%s.tmp -out .%s.tmp_out'%(PP,FN,FN))
	Xcluster=parseMuscleOut('.%s.tmp_out'%(FN))
	os.remove('.%s.tmp'%(FN))
	os.remove('.%s.tmp_out'%(FN))
	
	return Xcluster
	
#=======================================================================
	
def informationContent(row):
	# calculate information content for each row
	ic=2+row[0]*math.log(row[0],2)+row[1]*math.log(row[1],2)+row[2]*math.log(row[2],2)+row[3]*math.log(row[3],2)
	return ic
	
def buildConsensus(a):
	ca=""
	for i in a:
		i=[float(item) for item in i]
		y=[i[j]+i[k] for j in range(len(i)-1) for k in range(j+1,len(i))]
		t=['M','R','W','S','Y','K']
		if max(i)>0.6:
			ci='ACGT'[i.index(max(i))]
		elif max(y)>0.8:
			ci=t[y.index(max(y))]
		else:
			ci='N'
		ca+=ci
	return ca
			
#======================================================================
		
def buildMatrix(A):
	#==================================================================
	# A is the input motif segments before alignment
	# A format e.g.: A[0]=['ACGTAAAA',198]
	segA=list(set(A))
	A=[[item,A.count(item)] for item in segA]
	A=muscleAlign(A)
	# build matrix
	ic_cut=0.4 # information content cutoff
	#ic_cut=0 # information content cutoff
	dn={"A":0,"C":1,"G":2,"T":3}
	N=len(A[0])
	M=[]
	flag=0
	for i in range(N):
		fi=[]
		for j in A:
			fi.append(j[i])
		mi=[fi.count('A'),fi.count('C'),fi.count('G'),fi.count('T')]
		mi=[float(item)/sum(mi) for item in mi]
		pcount=0.01
		mi=[item+pcount for item in mi]
		mi=[float(item)/sum(mi) for item in mi]
		M.append(mi)
	IC=[informationContent(item) for item in M]
	IC_ID=[i for i in range(len(IC)) if IC[i]>=ic_cut]	
	ps=min(IC_ID)
	pe=max(IC_ID)
	M=M[ps:pe+1]
	A=list(set(A))
	A=[item[ps:pe+1] for item in A]
	return [M,A,IC_ID]


#---------------------------------------------------------------------	
# Get max clique for each node

def maxClique(G,CLK):
	# n node 
	MXC={}
	for i in G.nodes():
		A=nx.cliques_containing_node(G,nodes=i,cliques=CLK)
		AR=[float(sum(item))/len(item) for item in A]
		MXC_i=A[AR.index(min(AR))]
		if MXC_i not in MXC.values():
			MXC[i]=MXC_i
	return MXC
	
#========================================================================================================

#=======================================================================
# Clique community to motif consenus:
# seg: all motif instances without repeats
# segments: all motif instances with repeats

def KLC2Con(KLC,freq,freqs,freqc,bg):
	PWM=[] # motif candidates
	MC=[]
	for i in KLC:
		vi=KLC[i]
		segments=reduce(lambda x,y: x+y,map(lambda x: [x[1]]*x[-1],[freq[item] for item in vi]))
		[M,seg,IC_ID]=buildMatrix(segments)
		pv=freq[i][2]
		CI=buildConsensus(M)
		MC.append([pv,CI,M,seg])
	return MC
	
#=======================================================================
# remove repeats and redundant
def rmConRe(*args):
	if len(args)==1:
		MC=args[0]
	if len(args)==2:
		MC=args[0]
	for i in range(len(MC)-1):
		for j in range(i+1,len(MC)):
			if MC[i]!=[] and MC[j]!=[]:
				MCI=MC[i][1]
				MCJ=MC[j][1]
				MCJ_rc=revcom(MCJ)
				flag=compare2Xmer(MCI,MCJ)+compare2Xmer(MCI,MCJ_rc)
				if flag:
					MC[j]=[]
	MC=[item for item in MC if item!=[]]
	return MC
				
#=======================================================================

#======================================================================
# pv

def seg_pvalue(seg,freqs,freqc):
	# A, after refine
	# B, original
	a=0
	b=0
	N=sum(freqs.values())
	Nc=sum(freqc.values())
	for i in seg:
		if i in freqs:
			a+=freqs[i]
		if i in freqc:
			b+=freqc[i]
		c=N-a
		d=Nc-b
	pv=fisherTest(a,b,c,d)
	return pv
		
#=======================================================================



def Clique(fname,cname,nmotifs):
	#===================================================================
	print('\npredicting monad motifs...')
	# Chip-seq data-----------------------------------------------------
	# frequency
	global FN
	FN=fname.split(os.sep)[-1]
	x=8
	w=200 # central peak region
	seq=readSeq(fname)
	#seqp=seq
	seqp=extracPeak(seq,w)
	[freqs,bg]=freqX(seqp,x)
	
	#Ctrl-Seq data
	ctrl=readSeq(cname)
	freqc=freqX(ctrl,x)[0]
	#
	freq=sigX(freqs,freqc,bg)
	#===================================================================
	# building graph
	S=similarX(freq)
	#pdb.set_trace()
	#pdb.set_trace()
	G=nx.Graph()
	G.add_nodes_from([item[0] for item in freq])
	G.add_edges_from(S)
	#==================================================================
	# finding clique
	print("\nfinding cliques...")
	CLK=nx.find_cliques(G)
	CLK=[clique for clique in CLK]
	#===================================================================
	# Get maximal clique for each node
	#
	KLC=maxClique(G,CLK)
	#pdb.set_trace()
	#===================================================================
	# clique  -> motif consensus
	MC=KLC2Con(KLC,freq,freqs,freqc,bg)
	#pdb.set_trace()
	#===================================================================
	# filter redundant and repeats
	RMC=rmConRe(MC)
	MP=positionX(seq,[item[-1] for item in RMC])
	RMC=[RMC[i]+[MP[i]] for i in xrange(len(RMC))]
	return RMC
	#===================================================================
	
	


	
	


