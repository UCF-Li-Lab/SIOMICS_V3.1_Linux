import pdb,sys,os,subprocess,copy,shutil
import Clique as cliq
import motif_compare as motc

#!/usr/bin/env python
"""
author: jun ding
date: 09/29/2015
function: this code is used to output the motif TBFS file

"""
def readFile(fname):
	f=open(fname,'r')
	lf=f.readlines()
	f.close()
	lf=[item.strip().split() for item in lf]
	return lf

def outputMot(A,FN,outputdir,stamp_comp,db,ec):
	MM=[]
	MC=[]
	for i in range(len(A)):
		t=A[i][2]
		for j in range(len(t)):
			t[j]=[str(item) for item in t[j]]
			t[j]=' '.join(t[j])
		t='\n'.join(t)
		MM.append('>'+str(i)+'\t'+str(A[i][0])+'\n'+t+'\n')
		MC.append('>'+str(i)+'\t'+str(A[i][0])+'\n'+A[i][1]+'\n')
	MC=''.join(MC)
	"""
	f=open("%s/%s.consensus"%(outputdir,FN),'w')
	f.write(MC)
	f.close()
	"""
	MM=''.join(MM)
	f=open("%s/%s.PWM"%(outputdir,FN),'w')
	f.write(MM)
	f.close()
	
	if stamp_comp!=0:
		f=open(db,'r')
		dbMM=f.readlines()
		f.close()
		dbMM=''.join(dbMM)
		#motc.STAMP_Compare(MM,FN,outputdir)
		PP=os.path.dirname(os.path.abspath(__file__))
		os.system('python %s/STAMP/STAMP_compare.py %s/%s.PWM %s %s' %(PP,outputdir,FN,db,ec))
		motc.STAMP_Compare(MM,dbMM,FN,outputdir)
def getTFBS(A,seq,FN,outputdir):
	T=[]
	for i in range(len(A)):
		ti=[]
		for j in A[i][-1]:
			mi=seq[j[0]][1][j[1]:j[2]]
			#mi=seq[j[0]][1][j[1]-4:j[2]+4]
			ti.append(seq[j[0]][0]+','+str(j[1])+','+str(j[2])+','+mi)
		ti='\n'.join(ti)
		T.append('>'+str(i)+':'+'\n'+ti+'\n')
	T=''.join(T)
	f=open('%s/%s.tfbs'%(outputdir,FN),'w')
	f.write(T)
	f.close()
			

def TFBSModule(A,seqname,outputdir,stamp_comp,db,ec):
	print("Generating motifs and TFBS files...")
	#########################################################################
	if os.path.exists(outputdir)==False:
		os.mkdir(outputdir)
	FN=seqname.split('/')[-1]
	outputMot(A,FN,outputdir,stamp_comp,db,ec)
	seq=cliq.readSeq(seqname)
	getTFBS(A,seq,FN,outputdir)
		
		
	
	
	
		
