#!/usr/bin/env python
"""
author: Jun Ding
since: 03/24/2015
"""

import pdb,sys,os

#######################################################################


########################################################################
#stamp comparison
# check the version of python

def STAMP_Compare(mot,mdb,FN,outputdir):
	PV=sys.version_info[0]
	if PV>2:
		import urllib.request 
		import urllib.parse 
		def check_internet():
			try:
				response=urllib.request.Request("http://www.google.com")
				#pdb.set_trace()
				re=urllib.request.urlopen(response)
				return True
			except:
				print("No internet access,please check!")
				sys.exit(0)

		#####################################################################
		# check internet access
		check_internet()
		
		print ("comparing predicted motifs with known motifs by using STAMP...")
		####################################################################
		# compare with JASPAR
		data={'input':mot,
			  'mtrim':'0.4',
			  'num_hits':'5',
			  'metric':'PCC',
			  'align':'SWU',
			  'mulalign':'IR',
			  'tree':'UPGMA',  
			   'match_db':'User',
			  'user_match_motif':mdb
		}

		data = urllib.parse.urlencode(data) 
		data = data.encode('utf-8') 
		req=urllib.request.Request("http://www.benoslab.pitt.edu/stamp/run.php?",data)
		#pdb.set_trace()
		f = urllib.request.urlopen(req)
		content=f.read().decode()
		content=content.split("onClick=")[1].split("http:")[1].split(" ")[0].split("html")[0]
		page="http:"+content+"html"
		html=urllib.request.urlopen(page)
		page_content=html.read().decode()
		pdf=page_content.split(".pdf")
		pdf=pdf[0].split("href=")[-1][1:]
		pdf=pdf+".pdf"
		urllib.urlretrieve(pdf, "%s/%s.STAMP.pdf"%(outputdir,FN))

	else:
		import urllib
		import urllib2
		def check_internet():
			try:
				#pdb.set_trace()
				response=urllib2.urlopen("http://www.google.com",timeout=1)
				return True
			except:
				print("No internet access,please check!")
				sys.exit(0)

		#####################################################################
		# check internet access
		check_internet()
		print ("comparing predicted motifs with known motifs by using STAMP...")
		####################################################################
		# compare with JASPAR
		data={'input':mot,
			  'mtrim':'0.4',
			  'num_hits':'5',
			  'metric':'PCC',
			  'align':'SWU',
			  'mulalign':'IR',
			  'tree':'UPGMA',
			  'match_db':'User',
			  'user_match_motif':mdb
			  
		}

		data = urllib.urlencode(data) 
		f = urllib2.urlopen("http://www.benoslab.pitt.edu/stamp/run.php?",data)
		content=f.read()
		content=content.split("onClick=")[1].split("http:")[1].split(" ")[0].split("html")[0]
		page="http:"+content+"html"
		html=urllib.urlopen(page)
		page_content=html.read()
		pdf=page_content.split(".pdf")
		pdf=pdf[0].split("href=")[-1][1:]
		pdf=pdf+".pdf"
		urllib.urlretrieve(pdf, "%s/%s.STAMP.pdf"%(outputdir,FN))
		####################################################################
		
