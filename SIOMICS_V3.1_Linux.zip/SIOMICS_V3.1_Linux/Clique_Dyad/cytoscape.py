#!/usr/bin/env python
"""
author: jun ding
since: 09/24/2013
function: this code is used to generate .sif foramt interaction map , which can be used by Cytoscaple to generate interaction map.
"""

########################################################################
## generate .sif format interaction file
import pdb,sys,os,subprocess
import threading

def cytoscape(lf,outputdir,FN):
	lf=[item.strip() for item in lf]
	lf=[item.split() for item in lf]
	lf=[item[:-2] for item in lf]
	d={}
	for i in lf:
		for j in range(len(i)-1):
			for k in range(j+1,len(i)):
				pair=i[j]+" "+"pp"+" "+i[k]
				if pair not in d:
					d[pair]=0
	mc=d.keys()
	mc="\n".join(mc)
	f=open('%s/%s.sif'%(outputdir,FN),'w')
	f.write(mc)
	f.close()			




