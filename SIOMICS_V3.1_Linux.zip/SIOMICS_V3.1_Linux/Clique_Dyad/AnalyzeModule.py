#!/usr/bin/env python

"""
author: jun ding
"""
import pdb,sys,os,subprocess,copy,shutil,re
import Clique as cliq
from StatTest import *

class Hit:
	def __init__(self,hid,s,tar,hs,he):
		self.hid=hid
		self.hs=hs
		self.he=he
		self.tar=tar
		self.s=s
		
def List2Text(A,fpath):
	for i in range(len(A)):
		A[i]=[str(item) for item in A[i]]
		A[i]=' '.join(A[i])+'\n'
	A=''.join(A)
	f=open(fpath,'w')
	f.write(A)
	f.close()
	
def filterRed(LH,cut):
	# LH: list of Hits objects
	for i in range(len(LH)):
		for j in range(len(LH[i])-1):
			for k in range(j+1,len(LH[i])):
				if LH[i][j]!=None and LH[i][k]!=None and abs(LH[i][k].hs)-abs(LH[i][j].hs)<cut:
					LH[i][k]==None
		LH[i]=[item for item in LH[i] if item!=None]
	return LH
	
def FimModule(transPath,S):
	PP=os.path.dirname(os.path.abspath(__file__))
	os.system('%s/fim_maximal %s %s %s'%(PP,transPath,S,transPath+'.fimout'))
	try:
		f=open(transPath+'.fimout','r')
		lf=f.readlines()
		f.close()
		lf=[item.strip().split() for item in lf]
		return lf
	except:
		print('no module found!')
		return []
	
def prob_mot(A,CT):
	MI=[item[3] for item in A]
	for i in xrange(len(MI)):
		MI[i]=[''.join([item for item in j if item!='-']) for j in MI[i]]
	rcm=[]
	for i in MI:
		ct=0
		ki='|'.join(i)
		pi=re.compile(ki)
		for j in CT:
			if pi.search(j[1]):
				ct+=1
		rcm.append(ct)
	n=len(CT)
	pm=[float(item)/n for item in rcm]
	return pm
	
def sigModule(mod,pm,G,C):
	# G is total # of real sequences 
	out=[]
	for i in mod:
		mci=[int(item) for item in i[:-1]]
		g=int(i[-1][1:-1])
		if len(mci)>0:
			pi=reduce(lambda x,y:x*y,[pm[item] for item in mci])
			pv=1-pbinom(g-1,G,pi)
			cpv=pv*len(mod)
			if (cpv<C) and (len(mci)>=2) and (len(mci)<=6):
				out.append(' '.join(i)+' '+'('+str(cpv)+')'+'\n')
	return out
		
def AnalyzeModule(A,outputdir,inputseqname,ctrlseqname,S,C):
	## choosing top M motifs from candidate list -A
	## outputdir: output directory 
	## S: support value for mc finding
	## C: p-value cutoff
	print('\nAnalyzing motif modules...')
	H=[item[-1] for item in A]
	AL=[]
	cut=4 # 4bps for filtering non-redundant
	FN=inputseqname.split(os.sep)[-1]
	seq=cliq.readSeq(inputseqname)
	ctrl=cliq.readSeq(ctrlseqname)
	
	# 
	pm=prob_mot(A,ctrl)
	#===================================================================
	for i in xrange(len(H)):
		hi=[Hit(i,A[i][0],item[0],item[1],item[2]) for item in H[i]]
		AL+=hi
	
	LH=[]
	for i in xrange(len(seq)):
		Hi=[item for item in AL if item.tar==i]
		LH.append(Hi)
	NRH=filterRed(LH,cut)
	
	Transaction=[]
	for i in NRH:
		Ti=[]
		for j in i:
			if j.hid not in Ti:
				Ti.append(j.hid)
		Transaction.append(Ti)
	if os.path.exists(outputdir)==False:
		os.mkdir(outputdir)
	List2Text(Transaction,outputdir+'/'+FN+'.trans')
	mod=FimModule(outputdir+'/'+FN+'.trans',S)
	os.remove(outputdir+'/'+FN+'.trans'+'.fimout')
	sigmod=sigModule(mod,pm,len(seq),C)
	#===============================================
	return sigmod

	
	
	
