import pdb,sys,os
from StatTest import *
import Clique as cliq
import re
			
def revcom(A):
	dN={'A':'T','C':'G','G':'C','T':'A','.':'.','N':'N'}
	A=A.upper()
	A=[dN[item] for item in A]
	A=A[::-1]
	A=''.join(A)
	return A
	
def bG(S):
	bg=[0,0,0,0]
	for i in S:
		seqi=i[1]
		bg[0]+=seqi.count('A')
		bg[1]+=seqi.count('C')
		bg[2]+=seqi.count('G')
		bg[3]+=seqi.count('T')
	bg=[float(item)/sum(bg) for item in bg]
	return bg
		
def freqX(x,sl,Seq):
	#x: length of spacer
	#sl: length of dyad signal
	dx={}
	for i in Seq:
		for j in range(len(i[1])-(x+sl*2)+1):
			xmer=i[1][j:j+x+sl*2]
			quad1=xmer[0:sl]
			quad2=xmer[-1*sl:]
			spacer='.'*x
			sp=xmer[sl:-1*sl]
			sc=[[0,0,0,0]]*len(sp)
			if (len(quad1)==sl)and(len(quad2)==sl):	
				key=quad1+spacer+quad2
				key_rc=revcom(key)
				if 'N' not in xmer:
					if key not in dx:
						for k in xrange(len(sp)):
							sc[k]['ACGT'.index(sp[k])]+=1
						dx[key]=sc
					else:
						for k in xrange(len(sp)):
							dx[key][k]['ACGT'.index(sp[k])]+=1
							
	return dx

def getHits(x,sl,Seq):
	x1=x[:sl]
	x2=x[-1*sl:]
	ns=len(x)-2*sl
	spacer='.'*ns
	p=re.compile(x1+spacer+x2)
	H=[]
	for i in xrange(len(Seq)):
		s=Seq[i][1]
		loc=[(i,item.start(),item.end()) for item in p.finditer(s)]
		H+=loc
	return H

def checkSpacer(dx):
	NS=[]
	for i in dx:
		flag=[]
		for j in dx[i]:
			j=[float(item)/sum(j) for item in j]
			y=[j[q]+j[p] for q in range(len(j)-1) for p in range(q+1,len(j))]
			if max(j)>0.5:
				flag.append(1)
			elif max(y)>0.6:
				flag.append(1)
			else:
				flag.append(0)
		if max(flag)==0:
			NS.append(i)
	return NS
	
	
def seg_pvalue(i,freqs,freqc):
	# A, after refine
	# B, original
	a=0
	b=0
	randomSizeCorrectFactor=2
	N=sum(freqs.values())
	Nc=sum(freqc.values())
	if i in freqs:
		a+=freqs[i]
		N=N-freqs[i]*len(i)
	if i in freqc:
		b+=freqc[i]
		Nc=Nc-freqc[i]*len(i)
	b=b*randomSizeCorrectFactor
	c=N-a
	d=Nc-b
	pv=fisherTest(a,b,c,d)
	return pv
					
	

def buildMatrix(A):
	dm={'A':[0.97,0.01,0.01,0.01],'C':[0.01,0.97,0.01,0.01],'G':[0.01,0.01,0.97,0.01],'T':[0.01,0.01,0.01,0.97],'.':[0.25,0.25,0.25,0.25],'N':[0.25,0.25,0.25,0.25]}
	M=[dm[item] for item in A]
	return M

def Xextend(x,H,Seq,Ctrl):
	exl=2
	LX=[Seq[item[0]][1][max(0,item[1]-exl):item[1]] for item in H]
	LX=[item for item in LX if 'N' not in item and len(item)==exl]
	RX=[Seq[item[0]][1][item[2]:item[2]+exl] for item in H]
	RX=[item for item in RX if 'N' not in item and len(item)==exl ]
	ALX=""
	ARX=""
	bg=bG(Seq)
	cut=1e-5
	for i in xrange(exl):
		C1=[0,0,0,0]
		for j in LX:
			C1['ACGT'.index(j[i])]+=1
		pvl=[1-pbinom(C1[i]-1,sum(C1),bg[i]) for i in xrange(len(C1))]
		if min(pvl)<cut:
			ALX+='ACGT'[pvl.index(min(pvl))]
		else:
			ALX+='N'
			
	for i in xrange(exl):
		C2=[0,0,0,0]
		for j in RX:
			C2['ACGT'.index(j[i])]+=1
		pvr=[1-pbinom(C2[i]-1,sum(C2),bg[i]) for i in xrange(len(C2))]
		if min(pvr)<cut:
			ARX+='ACGT'[pvr.index(min(pvr))]
		else:
			ARX+='N'
	if (x==revcom(x)) and (ALX==revcom(ARX)):
		cs=ALX+x+ARX
		csi=[i for i in xrange(len(cs)) if cs[i]!='N']
		cs=cs[csi[0]:csi[-1]+1]
		cs1=ALX+x
		cs1i=[i for i in xrange(len(cs1)) if cs1[i]!='N']
		cs1=cs1[cs1i[0]:cs1i[-1]+1]
		re_cs=re_estimate(cs,Seq,Ctrl)
		re_cs1=re_estimate(cs1,Seq,Ctrl)
		tolerance=1000
		try:
			ratio_cs_cs1=re_cs[1]/re_cs1[1]
			if ratio_cs_cs1>tolerance:
				return cs1
			else:
				return cs
		except:
			return cs	
	else:
		cs=ALX+x+ARX
		return cs
	
def Dyad_positionX(S,segs):
	# segs is a list of X-mer list
	MP=[]
	for x in segs:
		p=re.compile(x[0])
		H=[]
		for i in xrange(len(S)):
			s=S[i][1]
			loc=[(i,item.start(),item.end()) for item in p.finditer(s)]
			H+=loc
		MP.append(H)
	return MP
				
def re_estimate(a,Seq,Ctrl):
	p=re.compile(a)
	x=0.01
	y=0.01
	N=0
	NC=0
	for i in xrange(len(Seq)):
		s=Seq[i][1]
		N+=len(s)-len(a)+1
		loc=[(i,item.start(),item.end()) for item in p.finditer(s)]
		x+=len(loc)
	for i in xrange(len(Ctrl)):
		s=Ctrl[i][1]
		loc=[(i,item.start(),item.end()) for item in p.finditer(s)]
		y+=len(loc)
		NC+=len(s)-len(a)+1
	randomSizeCorrectFactor=4
	pv=fisherTest(x,y*randomSizeCorrectFactor,N,NC)
	return [a,pv,x,y]
	
							
#====================================================================================================
# read in sequence

def dyad(fname,cname,nmotifs):
	print('\npredicting dyad motifs...')
	w=200 # length of critial peak region
	cut=1e-20
	Seq=cliq.readSeq(fname)
	Seqp=cliq.extracPeak(Seq,w)
	Ctrl=cliq.readSeq(cname)
	# frequency
	D=[] # dyad motifs
	sl=3 # signal length
	MAX_GAP=7
	MIN_GAP=2
	for x in range(MIN_GAP,MAX_GAP):
		#print(x)
		#===========================
		freqx=freqX(x,sl,Seqp)
		freqc=freqX(x,sl,Ctrl)
		##==========================
		NS=checkSpacer(freqx)
		freqx={i:sum(freqx[i][0]) for i in freqx}
		freqc={i:sum(freqc[i][0]) for i in freqc}
		for i in NS:
			pv=seg_pvalue(i,freqx,freqc)
			pv=pv*(4**(sl*2+x))
			D.append([i,pv,freqx[i],freqc[i]])
		cliq.progressbar(x,MAX_GAP-1)
	D.sort(key=lambda x: (x[1],float(x[3])/x[2]))
	#pdb.set_trace()
	D=[item for item in D if item[1]<cut]
	for i in xrange(len(D)):
		x=D[i][0]
		Hi=getHits(x,sl,Seqp)
		xe=Xextend(x,Hi,Seqp,Ctrl)
		D[i][0]=xe
	for i in range(len(D)):
		D[i]=re_estimate(D[i][0],Seqp,Ctrl)
	D.sort(key=lambda x: (x[1],-1*x[2]))
	D=[item for item in D if item[1]<cut]
	M=[[item[1],buildMatrix(item[0]),item[0]] for item in D]
	MC=[[item[0],cliq.buildConsensus(item[1]),item[1],[item[2]]] for item in M]
	RMC=cliq.rmConRe(MC)
	RMC=RMC[:nmotifs]
	MP=Dyad_positionX(Seq,[item[-1] for item in RMC])
	RMC=[RMC[i]+[MP[i]] for i in xrange(len(RMC))]
	return RMC
	
#=======================================================================================================


