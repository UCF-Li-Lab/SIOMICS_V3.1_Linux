import pdb,sys,os
os.system('perl FormatMatrices.pl %s %s.out'%(sys.argv[1],sys.argv[1]))
os.system('./STAMP -tf %s.out -sd JaspRand_PCC_SWU.scores -match %s'%(sys.argv[1],sys.argv[2]))
