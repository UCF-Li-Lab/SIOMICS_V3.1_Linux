#!/usr/bin/env python
import pdb,sys,os,math
def informationContent(row):
	row=[float(item) for item in row.split()]
	#pdb.set_trace()
	# calculate information content for each row
	ic=2+row[0]*math.log(row[0],2)+row[1]*math.log(row[1],2)+row[2]*math.log(row[2],2)+row[3]*math.log(row[3],2)
	#pdb.set_trace()
	return ic

def readMat(fname):
	f=open(fname,'r')
	lf=f.readlines()
	f.close()
	lf=''.join(lf)
	lf=lf.split('>')[1:]
	for i in range(len(lf)):
		lf[i]=lf[i].split('\n')
		lf[i]=[item for item in lf[i] if item!='']
	return lf
	#pdb.set_trace()

def formatMat(A,ID):
	ID='DE'+'\t'+ID
	for i in range(len(A)):
		A[i]=str(i)+'\t'+A[i]
	A=ID+'\n'+'\n'.join(A)+'\n'+'XX'
	return A
		
		
pwm=readMat(sys.argv[1])
transfac=[]
for i in pwm:
	ID=i[0]
	IC=[informationContent(item) for item in i[1:]]
	IC_ID=[j for j in range(len(IC)) if IC[j]>=0.4]	
	ps=min(IC_ID)
	pe=max(IC_ID)
	i=i[1:][ps:pe+1]
	ti=formatMat(i,ID)
	transfac.append(ti)
transfac='\n'.join(transfac)
f=open(sys.argv[1]+'.FT','w')
f.write(transfac)
f.close()
