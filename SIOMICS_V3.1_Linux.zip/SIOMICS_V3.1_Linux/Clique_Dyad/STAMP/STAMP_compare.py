#!/usr/bin/env python
import pdb,sys,os,uuid
# 1: PWM
# 2: database
# 3: E-value cutoff
# 4. output
def parseOut(A,cut):
	f=open(A,'r')
	lf=f.readlines()
	f.close()
	lf="".join(lf)
	lf=lf.split('>')[1:]
	DTF={}
	for i in range(len(lf)):
		lf[i]=lf[i].split('\n')
		lf[i]=[item for item in lf[i] if item!='']
		#pdb.set_trace()
		if len(lf[i])>1:
			ID=lf[i][0]
			TF=[]
			for j in range(1,len(lf[i])):
				lf[i][j]=lf[i][j].split('\t')
				ev=float(lf[i][j][1])
				tf=lf[i][j][0]
				if ev>cut:
					lf[i][j]=''
				else:
					TF.append(tf)
				lf[i][j]='\t'.join(lf[i][j])
		lf[i]=[item for item in lf[i] if item!='']
		lf[i]='>'+'\n'.join(lf[i])+'\n'
		DTF[i]=TF
	return [lf,DTF]

def updatePWM(A,DTF):
	f=open(A,'r')
	lf=f.readlines()
	f.close()
	lf="".join(lf)
	lf=lf.split('>')[1:]
	for i in range(len(lf)):
		lf[i]=lf[i].split('\n')
		lf[i][0]='>'+lf[i][0]+'\t'+'('+','.join(DTF[i])+')'
		lf[i]='\n'.join(lf[i])
	return lf
	
def writePWM(A,out):
	A=''.join(A)
	f=open(out,'w')
	f.write(A)
	f.close()
	
	
pwm=sys.argv[1]
db=sys.argv[2]
cut=float(sys.argv[3])
output=str(uuid.uuid1())
PP=os.path.dirname(os.path.abspath(__file__))
#-----------------------------------------------------------------------
os.system('python %s/formatMat.py %s' %(PP,sys.argv[1]))
os.system('%s/STAMP -tf %s.FT -sd %s/JaspRand_PCC_SWU.scores -cc PCC -align SWU -tree UPGMA -ma IR -go 0.5 -ge 0.25 -match %s -out %s'%(PP,pwm,PP,db,output))
os.remove('%s.tree'%(output))
os.remove('%sFBP.txt'%(output))
os.remove('%s_matched.transfac'%(output))
[A,DTF]=parseOut('%s_match_pairs.txt'%(output),cut)
PU=updatePWM(sys.argv[1],DTF)
writePWM(PU,sys.argv[1])
writePWM(A,sys.argv[1]+'.TFs')
os.remove('%s_match_pairs.txt'%(output))
os.remove('%s.FT'%(sys.argv[1]))
