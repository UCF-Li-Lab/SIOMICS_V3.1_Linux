import pdb,sys,os
import AnalyzeModule

def IterativeFind(A,outputdir,inputseqname,ctrlseqname,S,C,nmotifs):
	pl=0
	pr=pl+nmotifs 
	TA=A[pl:pr]
	flag=1
	ct=0
	while flag:
		sigMod=AnalyzeModule.AnalyzeModule(TA,outputdir,inputseqname,ctrlseqname,S,C)
		sigMod=[item.strip().split()[:-2] for item in sigMod]
		mim=[]
		for i in sigMod:
			i=[int(item) for item in i]
			mim+=i
		mim=list(set(mim))
		mim.sort()
		MM=[]
		AA=[TA[item] for item in mim]
		pl=pr
		pr=pr+(nmotifs-len(AA))
		if len(AA)==nmotifs or pr>=len(A):
			break	
		TA=AA+A[pl:pr]
		ct+=1
		print('loop ...'+str(ct))	
	return AA
	#pdb.set_trace()
