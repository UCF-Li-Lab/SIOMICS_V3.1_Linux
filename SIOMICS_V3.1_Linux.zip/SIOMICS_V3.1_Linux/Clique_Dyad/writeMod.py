#!/usr/bin/env python

import pdb,sys,os

def writeSig(sigMod,outputdir,FN):
	sigMod=''.join(sigMod)
	f=open('%s/%s.mc'%(outputdir,FN),'w')
	f.write(sigMod)
	f.close()
		

def writeMotInMod(A,sigMod,outputdir,FN):
	sigMod=[item.strip().split()[:-2] for item in sigMod]
	mim=[]
	for i in sigMod:
		i=[int(item) for item in i]
		mim+=i
	mim=list(set(mim))
	mim.sort()
	MM=[]
	#pdb.set_trace()
	for i in mim:
		t=A[i][2][:][:]
		for j in range(len(t)):
			t[j]=[str(item) for item in t[j]]
			t[j]=' '.join(t[j])
		t='\n'.join(t)
		MM.append('>'+str(i)+'\t'+str(A[i][0])+'\n'+t+'\n')
	MM=''.join(MM)
	f=open("%s/%s.InModule.PWM"%(outputdir,FN),'w')
	f.write(MM)
	f.close()
	
def writeMod(A,sigmod,outputdir,FN):
	writeSig(sigmod,outputdir,FN)
	#writeMotInMod(A,sigmod,outputdir,FN)
