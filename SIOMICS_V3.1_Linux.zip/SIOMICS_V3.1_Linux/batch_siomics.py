#!/usr/bin/env python
import pdb,sys,os

def readSeq(fname):
	f=open(fname,'r')
	lf=f.readlines()
	f.close()
	lf="".join(lf)
	lf=lf.split(">")
	lf=lf[1:]
	for i in range(len(lf)):
		lf[i]=lf[i].split("\n")
		lf[i]=[lf[i][0],''.join(lf[i][1:])]
	return lf
	
d1=sys.argv[1]
L=os.listdir(d1)

for i in L:
	seq=readSeq('%s/%s'%(d1,i))
	S=int(len(seq)*0.01)
	os.system('python SIOMICS3.py -i %s/%s -m 0 -n 100 -s %s -c 0.01 -o %s_out -t 1 -r 0 -d default -e 1e-5'%(d1,i,S,i))
	
	
