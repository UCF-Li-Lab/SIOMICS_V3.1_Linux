#!/usr/bin/env python





########################################################################
# importing depending modules
import pdb,sys,os,stat,time,shutil
import subprocess
import multiprocessing
import threading

p_version=sys.version_info[0]

python=sys.executable

# checking the version of python
if p_version<=2:
	try:
		import Tkinter
		from Tkinter import *
		from tkFileDialog import askopenfilename
	except:
		print ("Please install the Tkinter module first!")
		time.sleep(10)
		sys.exit(0)
		
elif p_version>=3:
	try:
		import tkinter
		from tkinter import *
		from tkinter.filedialog import askopenfilename
	except:
		print ("please install the tkinter module first!")
		time.sleep(10)
		sys.exit(0)
	

import webbrowser
########################################################################




########################################################################

########################################################################

class App:
	def __init__(self,master):
		
		###zero frame##################################################
		fheader=Frame(master)
		self.label_title=Label(fheader,text="Welcome to use SIOMICS 3.0", fg="black",font="Helvetica 16 bold italic")
		self.label_id=Label(fheader,text="Data Integration and Knowledge Discovery Lab\n University of Central Florida", fg="black",font="Times 10 bold italic")
		
		#pack manager
		self.label_title.pack(padx=6)
		self.label_id.pack(padx=6)
		fheader.pack(fill="x",pady=4)
		
		
		
		sep0=Frame(master,height=2,bd=1,relief=SUNKEN)
		sep0.pack(fill="x",pady=4)
		
		##first frame###################################################
		##file opener---------------------------------------------------
		fop=Frame(master)
		self.button1=Button(fop,text="Choose your input sequence (-i)",fg="black",command=self.load_file,width=30)
		self.v=StringVar()
		self.label1=Label(fop,textvariable=self.v,bg="gray",width=30)
		self.vn=StringVar()
		self.label2=Label(fop,textvariable=self.vn,bg="gray",width=30)
		self.button1.pack(side=LEFT,padx=6)
		self.label1.pack(side=LEFT,padx=20)
		self.label2.pack(side=LEFT,padx=20)
		fop.pack(fill="x",pady=6)
		
		## second Frame
		## mode selector
		fms=Frame(master)
		##----MODE ----------
		self.varex1=IntVar()
		self.label_ex1=Label(fms,text="Mode (-m):", width=30)
		self.rb0 = Radiobutton(fms, text="Monad", variable=self.varex1,value=0)
		self.rb1 = Radiobutton(fms, text="Dyad", variable=self.varex1,value=1)
		self.rb2 = Radiobutton(fms, text="Monad+Dyad",variable=self.varex1,value=2)
		self.label_ex1.pack(side=LEFT,padx=6)
		self.rb0.pack(side=LEFT,padx=20)
		self.rb1.pack(side=LEFT,padx=20)
		self.rb2.pack(side=LEFT,padx=20)
		fms.pack(fill='x',pady=6)
		
		fms1=Frame(master)
		self.varex12=IntVar()
		self.label_ex12=Label(fms1,text="Iterative (-r):", width=30)
		self.rb02 = Radiobutton(fms1, text="yes", variable=self.varex12,value=1)
		self.rb12= Radiobutton(fms1, text="no", variable=self.varex12,value=0)
		
		self.label_ex12.pack(side=LEFT,padx=6)
		self.rb02.pack(side=LEFT,padx=20)
		self.rb12.pack(side=LEFT,padx=20)
		fms1.pack(fill='x',pady=6)
		
		##Third Frame
		## paramters----------------------------------------
		sep=Frame(master,height=2,bd=1,relief=SUNKEN)
		sep.pack(fill="x",pady=4)
		pt=Frame(master)
		self.label_p=Label(pt,text="Parameters",fg="black",font=8)
		##grid manager
		self.label_p.pack(side="left",padx=6,pady=6)
		pt.pack(fill="x")

		
		
		##Fourth Frame###################################################
		## inputting parameters-----------------------------------------
		sf=Frame(master,bg="gray",borderwidth=1,relief=SUNKEN,pady=6)
		wid=60
		
		

		
		##--max # of motifs-----------------------------------
		self.label_m=Label(sf,text="Maximal number of output motifs (-n)",bg="gray",width=30)
		self.entry_m=Entry(sf)
		self.label_m2=Label(sf,text="The maximal number of output motifs. (default 100)",width=wid)
		#grid manager
		self.label_m.grid(row=2,column=0,padx=6,pady=2)
		self.entry_m.grid(row=2,column=1,padx=6,pady=2)
		self.label_m2.grid(row=2,column=2,padx=6,pady=2)

		
		##--significance cutoffs-------------------------------
		self.label_c=Label(sf,text="Significance level (-c)",bg="gray",width=30)
		self.entry_c=Entry(sf)
		self.label_c2=Label(sf,text="Corrected p-value cutoff (default 0.01)",width=wid)
		#grid manager
		self.label_c.grid(row=3,column=0,padx=6,pady=2)
		self.entry_c.grid(row=3,column=1,padx=6,pady=2)
		self.label_c2.grid(row=3,column=2,padx=6,pady=2)
		
		##--support value---------------------------------------
		self.label_s=Label(sf,text="Support value for pattern mining (-s)", bg="gray",width=30)
		self.entry_s=Entry(sf)
		self.label_s2=Label(sf,text="The minimum number of instances (Integer) required for defining a frequenet \n motif combination (default 1%, e.g. if 2000 input sequences, 2000*1%=20)", width=wid)
		#grid manager
		self.label_s.grid(row=4,column=0,padx=6,pady=2)
		self.entry_s.grid(row=4,column=1,padx=6,pady=2)
		self.label_s2.grid(row=4,column=2,padx=6,pady=2)
		
		
		#-------------------------------------------------------------------
		
		
		##--output direcotry----------------------------------------
		self.label_o=Label(sf,text="Output (-o)", bg="gray", width=30)
		self.entry_o=Entry(sf)
		self.label_o2=Label(sf,text="Directory for storing results (e.g. output)", width=wid)
		
		
		
		#--output direcotry
	 	
		#grid manager
		self.label_o.grid(row=6,column=0,padx=6,pady=2)
		self.entry_o.grid(row=6,column=1,padx=6,pady=2)
		self.label_o2.grid(row=6,column=2,padx=6,pady=2)
		
		
		############################################################
		
		##
		self.varex2=IntVar()
		self.label_ex2=Label(sf,text="STAMP Comparison", bg="gray", width=30)
		self.rb3 = Radiobutton(sf, text="Yes", variable=self.varex2,value=1)
		self.rb4 = Radiobutton(sf, text="No", variable=self.varex2,value=0)
		self.label_ex2.grid(row=7,column=0,padx=6,pady=2)
		self.rb3.grid(row=7,column=1,padx=6,pady=2)
		self.rb4.grid(row=7,column=2,padx=6,pady=2)
		
		
		#
		
		
		#===============================================================
		self.label_ev=Label(sf,text="STAMP E-value cutoff", bg="gray", width=30)
		self.entry_ev=Entry(sf)
		self.label_ev_legend=Label(sf,text="E-value cutoff for STAMP motif comparison (default. 1E-5)",width=wid)
		self.label_ev.grid(row=8,column=0,padx=6,pady=2)
		self.entry_ev.grid(row=8, column=1,padx=6,pady=2)
		self.label_ev_legend.grid(row=8,column=2,padx=6,pady=2)
		
		self.db=IntVar()
		self.dbv=StringVar()
		self.label_db=Label(sf,text="known TF motif database", bg="gray", width=30)
		self.rb_db1 = Radiobutton(sf, text="User Defined",variable=self.db,value=1,command=self.load_db)
		self.rb_db1_text=Label(sf,textvariable=self.dbv,width=20,bg="gray")
		self.rb_db2= Radiobutton(sf, text="Default", variable=self.db,value=0)
		
		
		self.label_db.grid(row=9,column=0,padx=6,pady=2)
		self.rb_db1.grid(row=9,column=1,padx=6,pady=2)
		self.rb_db1_text.grid(row=10,column=1,padx=6,pady=2)
		self.rb_db2.grid(row=9,column=2,padx=6,pady=2)
		
		
		
		
		sf.pack(fill="x")
		
		##Fourth Frame#################################################
		##--run---------------------------------------------------
		sep2=Frame(master,height=2,bd=1,relief=SUNKEN)
		sep2.pack(fill="x",pady=4)
		fhelp=Frame(master)
		go_help=Button(fhelp,text="Go Help!",command=self.openpage)
		go_run=Button(fhelp,text="Run!",command=self.run)
		self.v_end=StringVar()
		self.label_ending=Label(fhelp,textvariable=self.v_end,width=wid)
		##pack manager
		go_help.pack(side="left",padx=6,pady=2)
		go_run.pack(side="left",padx=6,pady=2)
		self.label_ending.pack(side="left",padx=6,pady=2)
		fhelp.pack(fill="x")
		
		#========================
		# output 
		"""
		fout=Frame(master)
		T = Text(fout, height=100, width=300)
		T.pack(side=LEFT)
		self.log=""
		T.insert(END,self.log)
		fout.pack(fill="x")
		"""
		
	##file opener function
	def load_file(self):
		self.fileName=askopenfilename()
		if self.fileName!="":
			self.FN=self.fileName.split("/")[-1]
			self.v.set(self.FN)
			self.count_gene()
			self.label_ending.update_idletasks()
			
	def load_db(self):
		self.dbName=askopenfilename()
		if self.dbName!="":
			self.dbFN=self.dbName.split("/")[-1]
			self.dbv.set(self.dbFN)
			self.rb_db1_text.update_idletasks()
			
	def count_gene(self):
		f=open(self.fileName,'r')
		lf=f.readlines()
		f.close()
		lf="".join(lf)
		lf=lf.split(">")[1:]
		#pdb.set_trace()
		self.vn.set("# of input sequences: "+str(len(lf)))
		
	def openpage(self):
		webbrowser.open_new("README.txt")
		
	def run(self):
		self.n=self.entry_m.get()
		self.c=self.entry_c.get()
		self.s=self.entry_s.get()
		self.o=self.entry_o.get()
		self.m=self.varex1.get()
		self.t=self.varex2.get()
		self.r=self.varex12.get()
		self.e=self.entry_ev.get()
		self.b=self.db.get()
		if self.b==0:
			self.d='default'
		else:
			self.d=self.dbName
		if self.t==0:
			self.d=0
			self.e=0
			
		flag=self.check_run()
		if flag:
			#self.show_run()
			self.p=threading.Thread(target=self.trun)
			self.p.start()
			
	def rename_output(self,o):
		i=1
		while(os.path.exists(o+"_"+str(i))==True):
			i+=1
		o=o+"_"+str(i)
		return o 
	
	def trun(self):
		self.v_end.set("Running...")
		self.label_ending.update_idletasks()
		os.system(python+' SIOMICS3.py -i "%s" -m %s -n %s -c %s -s %s  -o %s  -t %s -r %s -e %s -d %s' %(self.fileName,self.m,self.n,self.c,self.s,self.o,self.t, self.r,self.e,self.d))
		#procS=subprocess.Popen([python,'Clique_Dyad.py', "-i%s"%(self.fileName),"-m%s"%(self.m),"-n%s"%(self.n),"-c%s" %(self.c), "-s%s"%(self.s),"-o%s"%(self.o),"-t%s"%(self.t)],stdout=subprocess.PIPE)
		self.v_end.set("Done!")
		self.label_ending.update_idletasks()
	
	def show_run(self):
		self.v_end.set("Running...")
		self.label_ending.update_idletasks()
		
	def check_run(self):
		# check the inputs
		try:
			if os.path.exists(self.fileName)==False:
				self.v_end.set("Error!: -i Please specify your input sequence file!")
				self.label_ending.update_idletasks()
				return False
		except:
			self.v_end.set("Error!: -i Please specify your input sequence file!")
			self.label_ending.update_idletasks()
			return False

		try:
			int(self.m)
		except:
			self.v_end.set("Error!: -m (The number of output motifs) should be Integer!")
			self.label_ending.update_idletasks()
			return False
		try:
			float(self.c)
		except:
			self.v_end.set("Error!: -c (The corrected pvalue cut) should be Float!")
			self.label_ending.update_idletasks()
			return False
		try:
			int(self.s)
		except:
			self.v_end.set("Error!: -s (The frequency cut) should be Integer!")
			self.label_ending.update_idletasks()
			return False
		
		try:
			if os.path.exists(self.o)==False:
				self.o1=self.o
			else:
				self.o1=self.rename_output(self.o)
		except:
			self.v_end.set("Error!: -o The specified output folder name is invalid!")
			self.label_ending.update_idletasks()
			return False
		
		try:
			int(self.varex2.get())
		except:
			self.v_end.set("Error!: Please choose whether to do Motif Comparison with STAMP")
			self.label_ending.update_idletasks()
			return False
		
		try:
			int(self.varex1.get())
		except:
			self.v_end.set("Error!: Please choose the mode")
			self.label_ending.update_idletasks()
			return False
		
		try:
			int(self.varex12.get())
		except:
			self.v_end.set("Error!: Please choose the iterative")
			self.label_ending.update_idletasks()
			return False
			
		try:
			float(self.e)
		except:
			if self.t!=0:
				self.v_end.set("Error!: -e (STAMP E-value cutoff) should be Float!")
				self.label_ending.update_idletasks()
				return False
		try:
			if self.b==1:
				if os.path.exists(self.dbName)==False:
					self.v_end.set("Error!: -i Please specify your known motif database file correctly!")
					self.label_ending.update_idletasks()
					return False
		except:
			self.v_end.set("Error!: -i Please specify your known motif database file correctly!")
			self.label_ending.update_idletasks()
		return True	
########################################################################
# root level
def main():
	root=Tk()
	root.geometry("1000x600+200+200")
	root.title("SIOMICS 3.0")
	########################################################################
	app=App(root)
	root.mainloop()
	########################################################################

if __name__=='__main__':
	main()
